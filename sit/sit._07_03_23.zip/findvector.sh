find -name '*.cpp' -exec grep -r -l '#include <vector>' {} \;
