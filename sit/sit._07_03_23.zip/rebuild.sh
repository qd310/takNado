echo 'main.cpp' | entr g++ main.cpp -o main.exe
