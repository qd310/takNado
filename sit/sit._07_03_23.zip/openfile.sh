nano $(find ~ -type f | fzf)
