find -name 'how_far_are_you.txt' | grep -o -i '/' | wc -l
