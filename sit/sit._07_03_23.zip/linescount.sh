find -name '*.cpp' -exec cat {} \; | wc -l
