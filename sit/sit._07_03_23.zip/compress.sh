zip -r -j 'example.zip' . -i '*.cpp'
