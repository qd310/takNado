find -not -name '*.cpp' -delete
